using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ViewGems : ControllerGems
{
    
    public static Color SelectedColor = new Color(1f, 1f, 1f, 0.5f);
	public static Color NotSelectedColor = new Color(1f, 1f, 1f, 1f);
    public static Color EmptyColor = new Color(1f, 1f, 1f, 0f);

}
